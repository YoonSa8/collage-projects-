import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import keras
from keras import models
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from tensorflow.python.keras.layers import Dense
from keras import callbacks, regularizers
train_data = pd.read_csv('D://AI//digit-recognizer//train.csv')
test_data = pd.read_csv('D://AI//digit-recognizer//test.csv')
print(train_data.info())
print('#'*50)
print(test_data.info())

#Normalization and Reshape

print("Train Shape:", train_data.shape)
print("Test Shape:", test_data.shape)


x_train = (train_data.iloc[:, 1:].values).astype('float32')  # all pixel values
y_train = train_data.iloc[:, 0].values.astype('int32')  # only labels
# convert it and x_train to float to divide it by 255
x_test = test_data.values.astype('float32')

x_train = x_train.reshape(x_train.shape[0], 28, 28)
x_test = x_test.reshape(x_test.shape[0], 28, 28)

# normalize each value for each pixel for the entire vector for each input
x_train /= 255
x_test /= 255                               # make it in range form 0 to 1

print("Training matrix shape", x_train.shape)
print("Testing matrix shape", x_test.shape)

# encode label
y_train = keras.utils.to_categorical(
    y_train, 10)  # convert y_train to 10 classes

# Train , Test split

x_train, x_val, y_train, y_val = train_test_split(
    x_train, y_train, test_size=0.2, random_state=42)  # 42 in random_state to get the same output
print(x_train.shape)
print(x_val.shape)

print(y_train.shape)
print(y_val.shape)

# ANN model


model = Sequential()
# first layer
# input layer's neuron will be 784
model.add(keras.layers.Flatten(input_shape=(28, 28)))
# second layer
model.add(Dense(128, activation='relu'))
# third layer
model.add(Dense(128, activation='relu'))
# final layer
model.add(Dense(10, activation='softmax'))


model.summary()

# compile model
model.compile(loss='categorical_crossentropy',
              optimizer='adam', metrics=['accuracy'])
#early_stopping_monitor = callbacks.EarlyStopping(patience=3)


checkpoint = keras.callbacks.ModelCheckpoint(
    filepath="Wights.h5", verbose=1, save_best_only=True)
history = model.fit(x_train, y_train, validation_data=(
    x_val, y_val), batch_size=64, verbose=1, epochs=10, callbacks=[checkpoint])

# summarize
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'val'], loc='upper right')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'val'], loc='upper left')
plt.show()

# Evaluation
loss, accurecy = model.evaluate(x_val, y_val)
print(loss, accurecy)

# model.save('handwritten.model') # as long as we saved the model in the frist place set it as comment
